V svoji seminarski nalogi sem si želel odgovoriti na vprašanje "ali teža,
moč motorja ter rip goriva vplivajo na porabo avtomobila?".

Vizualiziral sem podatke zbrane iz ene od treh excel tabel evidence
registriranih vozil v sloveniji. Ti podatki niso 100% zanesljivi, a nam
vseeno dajo dobro predstavo na odgovor na naše vprašanje skozi
vizualizacijo. Podatki imajo približno 18000 vrstic po tem, ko sem jih
obdelal.
V zgornji vrstici si lahko izberemo tip goriva avtomobilov, v spodnji
vrstici pa si lahko iozberemo, kareti podatki bodo prikazani na x osi.
Drugi podatki (tisti, ki niso na x osi) so predstavljeni kot moč barve
pikic, ki predstavljajo posamezno vozilo.
Odgovor na vprašanje lahko vidimo tudi skozi vizualizacijo. Vidimo trend
navzgor pri upoštevanju teže in upoštevanju moči avtomobila, prav tako pa
vidimo trend navzgor pri tipu goriva. Ta trend se še posebno dobro vidi,
ko si na x osi izberemo težo. Zraven sem izračunal tudi povprečja,
ki hipotezo potrjujejo za tip goriva.
Poleg hipoteze pa lahko vidimo, da so dizelski avtomobili v povprečju težji
od bencinskih in imajo manjšo moč motorja. Opazimo lahko tudi, da je velika
večina močnejših motorjev ravno bencinskih. Lahko smo skoraj prepričani, da
so to bolj športno usmerjeni avtomobili, kar se vidi tudi po teži.